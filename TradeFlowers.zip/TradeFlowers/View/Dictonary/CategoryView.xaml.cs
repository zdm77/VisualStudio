﻿using System.Windows;

namespace TradeFlowers.View.Dictonary
{
    /// <summary>
    /// Логика взаимодействия для CategoryView.xaml
    /// </summary>
    public partial class CategoryView : Window
    {
        public CategoryView()
        {
            InitializeComponent();
        }
    }
}